'use client'

import React from 'react'
import Header from './Header'
import Hero from '../venta/HeroSection'
import Productes from '../venta/ProductesSection'
import Contacte from '../venta/ContactSection'
import Footer from '../components/Footer'
import Main from '../components/Main'

export default function LandingVenda() {
  return (
    <>
      <Header />

      <Main>
        <Hero />
        <Productes />
        <Contacte />
      </Main>

      <Footer />
    </>
  )
}
