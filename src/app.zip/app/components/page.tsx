'use client'

import React from 'react'
import Header from './Header'
import Hero from './HeroSection'
import Productes from '../venta/ProductesSection'
import Comentaris from '../venta/ComentarisSection'
import Contacte from '../receptes/ContactSection'
import Pastor from '../pastor/PastorSection'
import Footer from './Footer'
import Main from './Main'
import CabritsSection from '../venta/QualitatSelection'
import RamatSection from '../ramat/RamatSection'

export default function RocGonzalez() {


  return (
    <>
      <Header />
      
      {/* Menú mòbil */}

      <Main>
        <Hero />
        <CabritsSection />
        <RamatSection />
        <Productes />
        <Comentaris /> 
        <Contacte />
        <Pastor />
      </Main>
      
      <Footer />
    </>
  )
}
